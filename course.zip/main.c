/**
 * 
 * @file main.c
 * @author Xianpi Duan (duanx14@macmaster.ca)
 * @brief Runs demonstration code for Student Course Management Library 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @mainpage Student Course Management Library demonstration
 * The Student Course Management Library function demonstration shows how multiple functions in the course and student 
 * library work, including:
 * - Randomly generated students
 * - Students enrolled in the course
 * - Printing out Course Information
 * - Get the Students with the highest average grades
 * - Printing out student grades
 * - Get number of students who passed this course
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * 
 * @brief Student Course Management Library demonstration
 * 
 * Create a course, randomly enroll 20 students, 
 * output the course information, 
 * get the highest average score, 
 * output the student information, 
 * get the number of students who passed, 
 * and output the passed student information. 
 * 
 * @return int 
 */
int main()
{
  srand((unsigned) time(NULL));
  // Create a course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8)); // enroll 20 random students
  
  print_course(MATH101); // Printing the course information

  Student *student; 
  student = top_student(MATH101); // Get the students with highest average grade
  printf("\n\nTop student: \n\n");
  print_student(student); // Printing out top student's information

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing); // Get the students who passed this course
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n"); // Printing out the information of all passed students
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}