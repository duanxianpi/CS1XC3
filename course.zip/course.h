/**
 * @file course.h
 * @author Xianpi Duan (duanx14@macmaster.ca)
 * @brief Course Library Header File
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief Course struct 
 * 
 * Course struct store course with name, course code, students and the number of students.
 * 
 */
typedef struct _course 
{
  char name[100]; /**< The char array for storing course name */
  char code[10]; /**< The char array for storing course code */
  Student *students; /**< Pointer to store students enrolled in the course */
  int total_students; /**< variable to store the number of students enrolled in the course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


