
/**
 * @file student.c
 * @author Xianpi Duan (duanx14@macmaster.ca)
 * @brief Student Library
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adding grade to student
 * 
 * If the student has previous grades,
 * it will expand the memeroy and store it at the end.
 * If not, it will calloc 1 size of double memeroy in heap for the student to store grades.
 * 
 * @param student Pointer to the student struct
 * @param grade Student's grade
 * @return void
 */

void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); // If student only has one grade, calloc 1 size of double memoery in heap to store.
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades); // If student has more than 1 grades, recalculate the size and realloc the memoery.
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Calculating the average grade of a student
 * 
 * @param student Pointer to the student struct
 * @return double 
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0; // If student has no record of grades return 0

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i]; // Adding all the grades together
  return total / ((double) student->num_grades); // Calculating the average
}

/**
 * @brief Printing out the information of student such as name, id and grades etc.
 * 
 * @param student Pointer to the student struct
 * @return void
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) //Traverse through all the student's grades and printing.
    printf("%.2f ", student->grades[i]); // Round the grades to 2 decimal.
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Generating a student randomly with the specific number of grades
 * 
 * @param grades The number of grades the student has
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]); // Random pick up a fisrt name and last name
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48); // Generate a 10 digital student number
  new_student->id[10] = '\0'; // Set the last char as '/0'

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75))); // Random generate the grades and adding them to student.
  }

  return new_student;
}