/**
 * @file student.h
 * @author Xianpi Duan (duanx14@macmaster.ca)
 * @brief Student Library Header File
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief Student struct
 * 
 * Student struct store student with first name, last name, student id, grades and the number of grades.
 */
typedef struct _student 
{ 
  char first_name[50]; /**< The char array for storing student first name */
  char last_name[50]; /**< The char array for storing student last name */
  char id[11]; /**< The char array for storing student id */
  double *grades; /**< Pointer to store students' grades */
  int num_grades; /**< Variable to store the number of grades student has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 