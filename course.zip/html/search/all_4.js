var searchData=
[
  ['first_5fname_0',['first_name',['../struct__student.html#a272ec3136434e8d3281a615cf31cc987',1,'_student']]]
];
