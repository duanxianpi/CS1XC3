var struct__student =
[
    [ "first_name", "struct__student.html#a272ec3136434e8d3281a615cf31cc987", null ],
    [ "grades", "struct__student.html#ad0f75a9ff0f6104eb9e3bb3c4f7ad97b", null ],
    [ "id", "struct__student.html#adaee78078859cdecdbe9128dd655b748", null ],
    [ "last_name", "struct__student.html#a18eb2a90671a2292c017b8f4fbde7eec", null ],
    [ "num_grades", "struct__student.html#a6592ee968ed2226737f45243e7602636", null ]
];