var course_8c =
[
    [ "enroll_student", "course_8c.html#af3abbc650ef56ffff427a62dad63fc77", null ],
    [ "passing", "course_8c.html#ab1ba9629dc52188231bb689d3a855813", null ],
    [ "print_course", "course_8c.html#a99bf8b3f3c2d5dc7cf798ed445eaaa77", null ],
    [ "top_student", "course_8c.html#ac1d82150824c7ecd43bab36fb83cd779", null ]
];