/**
 * @file course.c
 * @author Xianpi Duan (duanx14@macmaster.ca)
 * @brief Course Library
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief Enroll student into course
 * 
 * @param course pointer to the course struct
 * @param student pointer to the student struct
 * 
 * If this course has more than 1 student,
 * it will expand the memeroy and store the student at the end.
 * If not, it will calloc 1 size of Student memeroy in heap for course to store students.
 * 
 * @return void
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++; // Increasing the number of students
  if (course->total_students == 1) 
  {
    // If there is only one student in this course, calloc 1 size of Student in heap to store the student.
    course->students = calloc(1, sizeof(Student)); 
  }
  else 
  {
    course->students = 
      // If there is more than 1 students in this course, expand the memeroy 1 size of Student in the heap.
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
  // Append the student to the end.
}

/**
 * @brief Printing out the information of course such as name, code...
 * 
 * @param course pointer to the course struct
 * @return void
 * 
 * The information include Course name, code, total students and it will also print out the information of all the students enrolled in this course.
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) // Traverse through all the student and printing out their grades.
    print_student(&course->students[i]);
}

/**
 * @brief return the best student in this course
 * 
 * Select the student with the highest average grade by fast sorting
 * @param course pointer to the course struct
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; // Returns NULL if there are no students in this course
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average)  // Fast sorting algorithm that updates the highest grade when the student's average grade is higher than the highest average grade
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief return all students who passed this course
 * 
 * If student's average garde greater equal than 50, the student will pass this course. Otherwise, he/she won't pass this course.
 * @param course pointer to the course struct
 * @param total_passing pointer to varible which store the total passing.
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++; // Get the number of students who's average grade is larger than 50
  
  passing = calloc(count, sizeof(Student)); // Allocate appropriately sized memoery to store passed student information 

  int j = 0;
  for (int i = 0; i < course->total_students; i++) 
  {
    if (average(&course->students[i]) >= 50) // Store passed students into memory
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}